/* 
 * Various JavaScript functions
 */

( function( $ ) {
	
	$( 'p' ).has( 'img.aligncenter' ).addClass( 'centered-image');
	
} )( jQuery );

